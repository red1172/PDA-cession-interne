
* Merci d'utiliser les services Webophil Référencement!  Le fichier ZIP joint contient :

  favicon.ico  --  le fichier favicon.

  * Vous devez envoyer favicon.ico à la racine de votre site (là où se trouve le fichier index) et insérer ce code HTML entre les balises <head> ... </head>
    de votre page.

      <link rel="shortcut icon" href="favicon.ico">

  * FavIcon animé : si vous souhaitez afficher le favicon animé, envoyez le fichier 
    animated_favicon1.gif à la racine de votre site, et insérez le code suivant :

      <link rel="shortcut icon" href="favicon.ico" >
      <link rel="icon" href="animated_favicon1.gif" type="image/gif" >


* autres fichiers inclus dans le package

  * les fichiers suivants sont inclus pour information ou usage :

    - preview_16x16.png - 16*16 PNG image du favicon.
    - preview_32x32.png - 32*32 PNG image du favicon.
    - readme.txt - ce fichier.
    
Pour votre référencement, n'hésitez pas à utiliser les autres services offerts sur http://www.webophil.net
